"""
AI Planner Service - The Brain of the Application
Generates personalized study plans using rule-based logic + simple ML.
Uses scikit-learn for exam readiness prediction.
"""

from flask import Flask, request, jsonify
import datetime
import math
import logging
import os

# scikit-learn for ML predictions
from sklearn.linear_model import LinearRegression
import numpy as np

app = Flask(__name__)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# CORE LOGIC: Study Plan Generator
# ─────────────────────────────────────────────

def calculate_days_until_exam(exam_date_str):
    """Calculate how many days are left until the exam"""
    if not exam_date_str:
        return 30  # Default: assume 30 days if no exam date
    try:
        exam_date = datetime.datetime.strptime(exam_date_str, '%Y-%m-%d').date()
        today = datetime.date.today()
        delta = (exam_date - today).days
        return max(delta, 1)  # At least 1 day
    except:
        return 30


def get_priority_weight(priority):
    """Convert priority label to a numeric weight"""
    weights = {
        'high': 3.0,
        'medium': 2.0,
        'low': 1.0
    }
    return weights.get(priority, 2.0)


def generate_daily_schedule(subjects_data):
    """
    Main function: Generates a daily study schedule for each subject.
    
    Logic:
    1. Calculate urgency for each subject (priority × 1/days_left)
    2. Distribute daily hours proportionally
    3. Create a week-by-week timetable
    """
    schedule = []
    today = datetime.date.today()

    for subject in subjects_data:
        days_left = calculate_days_until_exam(subject.get('exam_date'))
        priority_weight = get_priority_weight(subject.get('priority', 'medium'))
        total_chapters = subject.get('total_chapters', 5)
        daily_hours = subject.get('daily_hours', 1.0)

        # Urgency score = how urgently this subject needs attention
        urgency_score = priority_weight * (1 / days_left) * 100

        # Sessions per week (study 5 days a week, rest on weekends)
        sessions_per_week = min(5, days_left)

        # Chapters per session
        chapters_per_session = round(total_chapters / max(days_left, 1), 2)

        schedule.append({
            'subject': subject['name'],
            'subject_id': subject['id'],
            'days_until_exam': days_left,
            'urgency_score': round(urgency_score, 2),
            'recommended_daily_hours': daily_hours,
            'chapters_per_day': chapters_per_session,
            'sessions_per_week': sessions_per_week,
            'priority': subject.get('priority', 'medium')
        })

    # Sort by urgency (most urgent first)
    schedule.sort(key=lambda x: x['urgency_score'], reverse=True)

    return schedule


def generate_weekly_timetable(schedule):
    """
    Generate a 7-day timetable showing what to study each day.
    Monday-Friday: Study days
    Saturday: Revision
    Sunday: Rest
    """
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    timetable = {}

    for i, day in enumerate(days):
        if day == 'Sunday':
            timetable[day] = [{'activity': 'Rest & Self-care', 'duration': '—'}]
        elif day == 'Saturday':
            # Revision day - go through all subjects briefly
            timetable[day] = [
                {'activity': f"Revision: {s['subject']}", 'duration': '30 min'}
                for s in schedule[:4]  # Top 4 subjects
            ]
        else:
            # Weekday: Assign subjects in rotation
            day_subjects = []
            # Pick subjects based on day index (rotate through)
            for j, subject in enumerate(schedule):
                if j % 5 == i % 5:  # Distribute across 5 weekdays
                    day_subjects.append({
                        'subject': subject['subject'],
                        'chapters': f"Chapter focus: {subject['chapters_per_day']:.1f}",
                        'duration': f"{subject['recommended_daily_hours']}h",
                        'pomodoro_sessions': int(subject['recommended_daily_hours'] * 2)  # 1 pomodoro = 25 min
                    })
            # Always add at least the top-priority subject
            if not day_subjects and schedule:
                top = schedule[0]
                day_subjects.append({
                    'subject': top['subject'],
                    'chapters': f"Chapter focus: {top['chapters_per_day']:.1f}",
                    'duration': f"{top['recommended_daily_hours']}h",
                    'pomodoro_sessions': int(top['recommended_daily_hours'] * 2)
                })
            timetable[day] = day_subjects

    return timetable


def predict_exam_readiness(subjects_data, progress_percent=50):
    """
    Simple ML model to predict exam readiness (0-100%).
    Uses Linear Regression trained on synthetic data.
    
    Features:
    - Days left until exam
    - Progress percentage
    - Priority weight
    - Daily study hours
    """
    # Synthetic training data (in real app, this comes from historical user data)
    # Format: [days_left, progress%, priority_weight, daily_hours] → readiness_score
    X_train = np.array([
        [30, 80, 3, 3],   # High readiness
        [14, 60, 2, 2],
        [7,  40, 1, 1],   # Low readiness
        [21, 70, 3, 2.5],
        [5,  20, 1, 1],
        [60, 50, 2, 2],
        [10, 90, 3, 3],
        [3,  10, 1, 0.5],
    ])
    y_train = np.array([95, 75, 40, 80, 20, 65, 92, 10])

    model = LinearRegression()
    model.fit(X_train, y_train)

    # Calculate average features across all subjects
    if not subjects_data:
        return 50  # Default readiness

    avg_days = sum(calculate_days_until_exam(s.get('exam_date')) for s in subjects_data) / len(subjects_data)
    avg_priority = sum(get_priority_weight(s.get('priority', 'medium')) for s in subjects_data) / len(subjects_data)
    avg_hours = sum(s.get('daily_hours', 1.0) for s in subjects_data) / len(subjects_data)

    features = np.array([[avg_days, progress_percent, avg_priority, avg_hours]])
    readiness = model.predict(features)[0]

    # Clamp between 0 and 100
    return round(max(0, min(100, readiness)), 1)


def generate_pomodoro_plan(subjects_schedule):
    """
    Generate a Pomodoro timer plan.
    Pomodoro = 25 min study + 5 min break
    After 4 pomodoros = 15 min long break
    """
    pomodoro_plan = []
    for subject in subjects_schedule[:3]:  # Top 3 subjects per day
        sessions = subject.get('pomodoro_sessions', 2)
        pomodoro_plan.append({
            'subject': subject['subject'],
            'pomodoros': sessions,
            'study_time': f"{sessions * 25} minutes",
            'short_breaks': sessions,
            'long_break': '15 min after every 4 pomodoros',
            'total_time': f"{sessions * 30} minutes (including breaks)"
        })
    return pomodoro_plan


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy', 'service': 'ai-planner-service'}), 200


@app.route('/generate', methods=['POST'])
def generate_plan():
    """
    Generate a complete, personalized study plan.
    Body: { "user_id": 1, "subjects": [...], "progress_percent": 30 }
    """
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        subjects_data = data.get('subjects', [])
        progress_percent = data.get('progress_percent', 30)

        if not subjects_data:
            return jsonify({'error': 'No subjects provided'}), 400

        logger.info(f"Generating plan for user {user_id} with {len(subjects_data)} subjects")

        # Step 1: Generate subject schedule (sorted by urgency)
        subject_schedule = generate_daily_schedule(subjects_data)

        # Step 2: Generate weekly timetable
        weekly_timetable = generate_weekly_timetable(subject_schedule)

        # Step 3: Predict exam readiness
        readiness_score = predict_exam_readiness(subjects_data, progress_percent)

        # Step 4: Pomodoro plan
        pomodoro_sessions = []
        for s in subject_schedule:
            s['pomodoro_sessions'] = s.get('sessions_per_week', 2)
        pomodoro_plan = generate_pomodoro_plan(subject_schedule)

        # Step 5: Generate smart recommendations
        recommendations = []
        for s in subject_schedule:
            if s['days_until_exam'] <= 7:
                recommendations.append(f"⚠️ URGENT: {s['subject']} exam is in {s['days_until_exam']} days! Focus heavily.")
            elif s['days_until_exam'] <= 14:
                recommendations.append(f"📚 {s['subject']} needs more attention — exam in {s['days_until_exam']} days.")

        if readiness_score < 40:
            recommendations.append("🔴 Your overall readiness is low. Consider increasing daily study hours.")
        elif readiness_score < 70:
            recommendations.append("🟡 You're on track, but keep consistent daily studying.")
        else:
            recommendations.append("🟢 Great progress! Stay consistent and review past chapters.")

        # Build full response
        plan = {
            'user_id': user_id,
            'generated_at': str(datetime.datetime.now()),
            'exam_readiness_score': readiness_score,
            'readiness_label': 'High' if readiness_score >= 70 else ('Medium' if readiness_score >= 40 else 'Low'),
            'subject_priority_schedule': subject_schedule,
            'weekly_timetable': weekly_timetable,
            'pomodoro_plan': pomodoro_plan,
            'recommendations': recommendations,
            'total_subjects': len(subjects_data),
            'study_tip': "📖 Study the most urgent subject first every morning when your mind is fresh!"
        }

        logger.info(f"Plan generated for user {user_id}. Readiness: {readiness_score}%")
        return jsonify(plan), 200

    except Exception as e:
        logger.error(f"Plan generation error: {str(e)}")
        return jsonify({'error': f'Plan generation failed: {str(e)}'}), 500


@app.route('/readiness', methods=['POST'])
def check_readiness():
    """
    Quick exam readiness check.
    Body: { "subjects": [...], "progress_percent": 60 }
    """
    try:
        data = request.get_json()
        subjects = data.get('subjects', [])
        progress = data.get('progress_percent', 50)

        score = predict_exam_readiness(subjects, progress)

        return jsonify({
            'readiness_score': score,
            'label': 'High' if score >= 70 else ('Medium' if score >= 40 else 'Low'),
            'message': f"Your exam readiness is {score}%. {'Keep it up!' if score >= 70 else 'More practice needed.'}"
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    logger.info("AI Planner Service started")
    app.run(host='0.0.0.0', port=5003, debug=False)
