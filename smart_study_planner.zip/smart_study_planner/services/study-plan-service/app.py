"""
Study Plan Service - Manages subjects, syllabus, and deadlines
Students input their study information here.
"""

from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
import requests
import datetime
import os
import logging

app = Flask(__name__)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL',
    'mysql+pymysql://root:password@mysql:3306/study_planner'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# URL for User Service (for token verification)
USER_SERVICE_URL = os.environ.get('USER_SERVICE_URL', 'http://user-service:5001')
AI_PLANNER_URL = os.environ.get('AI_PLANNER_URL', 'http://ai-planner-service:5003')


# ─────────────────────────────────────────────
# DATABASE MODELS
# ─────────────────────────────────────────────

class Subject(db.Model):
    """Stores all subjects for each student"""
    __tablename__ = 'subjects'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    name = db.Column(db.String(100), nullable=False)           # e.g., "Mathematics"
    total_chapters = db.Column(db.Integer, default=0)          # Total chapters in syllabus
    priority = db.Column(db.String(20), default='medium')      # high / medium / low
    exam_date = db.Column(db.Date, nullable=True)              # When is the exam?
    daily_hours = db.Column(db.Float, default=1.0)             # Hours to study per day
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'name': self.name,
            'total_chapters': self.total_chapters,
            'priority': self.priority,
            'exam_date': str(self.exam_date) if self.exam_date else None,
            'daily_hours': self.daily_hours,
            'created_at': str(self.created_at)
        }


class StudyPlan(db.Model):
    """Stores the generated study plan for each user"""
    __tablename__ = 'study_plans'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    plan_data = db.Column(db.Text, nullable=False)         # JSON string of the full plan
    generated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)        # Only one active plan at a time

    def to_dict(self):
        import json
        return {
            'id': self.id,
            'user_id': self.user_id,
            'plan_data': json.loads(self.plan_data),
            'generated_at': str(self.generated_at),
            'is_active': self.is_active
        }


# ─────────────────────────────────────────────
# HELPER: Verify JWT Token with User Service
# ─────────────────────────────────────────────
def verify_user_token(token):
    """Call the User Service to verify the JWT token"""
    try:
        response = requests.post(
            f"{USER_SERVICE_URL}/verify",
            json={'token': token},
            timeout=5
        )
        if response.status_code == 200:
            return response.json()
        return None
    except Exception as e:
        logger.error(f"Token verification failed: {str(e)}")
        return None


def get_token_from_header():
    """Extract Bearer token from Authorization header"""
    auth_header = request.headers.get('Authorization', '')
    if auth_header.startswith('Bearer '):
        return auth_header.split(' ')[1]
    return None


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy', 'service': 'study-plan-service'}), 200


@app.route('/subjects', methods=['POST'])
def add_subject():
    """
    Add a new subject to study
    Headers: Authorization: Bearer <token>
    Body: { "name": "Math", "total_chapters": 10, "priority": "high", "exam_date": "2024-12-01", "daily_hours": 2 }
    """
    token = get_token_from_header()
    if not token:
        return jsonify({'error': 'Authorization token required'}), 401

    user_info = verify_user_token(token)
    if not user_info:
        return jsonify({'error': 'Invalid or expired token'}), 401

    user_id = user_info['user_id']
    data = request.get_json()

    if not data or not data.get('name'):
        return jsonify({'error': 'Subject name is required'}), 400

    # Parse exam date if provided
    exam_date = None
    if data.get('exam_date'):
        try:
            exam_date = datetime.datetime.strptime(data['exam_date'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400

    subject = Subject(
        user_id=user_id,
        name=data['name'],
        total_chapters=data.get('total_chapters', 0),
        priority=data.get('priority', 'medium'),
        exam_date=exam_date,
        daily_hours=data.get('daily_hours', 1.0)
    )

    db.session.add(subject)
    db.session.commit()

    logger.info(f"Subject added: {data['name']} for user {user_id}")
    return jsonify({'message': 'Subject added successfully', 'subject': subject.to_dict()}), 201


@app.route('/subjects', methods=['GET'])
def get_subjects():
    """Get all subjects for the authenticated user"""
    token = get_token_from_header()
    if not token:
        return jsonify({'error': 'Authorization token required'}), 401

    user_info = verify_user_token(token)
    if not user_info:
        return jsonify({'error': 'Invalid or expired token'}), 401

    user_id = user_info['user_id']
    subjects = Subject.query.filter_by(user_id=user_id).all()

    return jsonify({'subjects': [s.to_dict() for s in subjects]}), 200


@app.route('/subjects/<int:subject_id>', methods=['DELETE'])
def delete_subject(subject_id):
    """Delete a subject"""
    token = get_token_from_header()
    if not token:
        return jsonify({'error': 'Authorization token required'}), 401

    user_info = verify_user_token(token)
    if not user_info:
        return jsonify({'error': 'Invalid or expired token'}), 401

    subject = Subject.query.filter_by(id=subject_id, user_id=user_info['user_id']).first()
    if not subject:
        return jsonify({'error': 'Subject not found'}), 404

    db.session.delete(subject)
    db.session.commit()
    return jsonify({'message': 'Subject deleted successfully'}), 200


@app.route('/generate-plan', methods=['POST'])
def generate_plan():
    """
    Trigger AI Planner to generate a study plan based on subjects
    """
    token = get_token_from_header()
    if not token:
        return jsonify({'error': 'Authorization token required'}), 401

    user_info = verify_user_token(token)
    if not user_info:
        return jsonify({'error': 'Invalid or expired token'}), 401

    user_id = user_info['user_id']

    # Get all subjects for this user
    subjects = Subject.query.filter_by(user_id=user_id).all()
    if not subjects:
        return jsonify({'error': 'No subjects found. Please add subjects first.'}), 400

    subjects_data = [s.to_dict() for s in subjects]

    # Call AI Planner Service to generate the plan
    try:
        ai_response = requests.post(
            f"{AI_PLANNER_URL}/generate",
            json={'user_id': user_id, 'subjects': subjects_data},
            timeout=30
        )

        if ai_response.status_code == 200:
            plan_data = ai_response.json()

            import json
            # Deactivate old plans
            old_plans = StudyPlan.query.filter_by(user_id=user_id, is_active=True).all()
            for p in old_plans:
                p.is_active = False

            # Save new plan
            new_plan = StudyPlan(
                user_id=user_id,
                plan_data=json.dumps(plan_data)
            )
            db.session.add(new_plan)
            db.session.commit()

            return jsonify({'message': 'Study plan generated!', 'plan': plan_data}), 200
        else:
            return jsonify({'error': 'AI planner failed to generate plan'}), 500

    except Exception as e:
        logger.error(f"AI planner call failed: {str(e)}")
        return jsonify({'error': 'Could not reach AI planner service'}), 503


@app.route('/plan', methods=['GET'])
def get_active_plan():
    """Get the current active study plan"""
    token = get_token_from_header()
    if not token:
        return jsonify({'error': 'Authorization token required'}), 401

    user_info = verify_user_token(token)
    if not user_info:
        return jsonify({'error': 'Invalid or expired token'}), 401

    user_id = user_info['user_id']
    plan = StudyPlan.query.filter_by(user_id=user_id, is_active=True).order_by(StudyPlan.generated_at.desc()).first()

    if not plan:
        return jsonify({'error': 'No active study plan found'}), 404

    return jsonify({'plan': plan.to_dict()}), 200


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        logger.info("Study Plan Service started")
    app.run(host='0.0.0.0', port=5002, debug=False)
