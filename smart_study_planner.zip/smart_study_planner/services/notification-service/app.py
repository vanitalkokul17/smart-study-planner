"""
Notification Service - Sends email reminders and alerts.
Uses Python's smtplib for SMTP email sending.
Supports: Study reminders, missed session alerts, exam countdown.
"""

from flask import Flask, request, jsonify
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
import datetime
import os
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# SMTP Configuration (set in environment variables)
SMTP_HOST = os.environ.get('SMTP_HOST', 'smtp.gmail.com')
SMTP_PORT = int(os.environ.get('SMTP_PORT', 587))
SMTP_USER = os.environ.get('SMTP_USER', 'your-email@gmail.com')
SMTP_PASSWORD = os.environ.get('SMTP_PASSWORD', 'your-app-password')
FROM_EMAIL = os.environ.get('FROM_EMAIL', 'noreply@smartstudy.com')

USER_SERVICE_URL = os.environ.get('USER_SERVICE_URL', 'http://user-service:5001')


# ─────────────────────────────────────────────
# EMAIL SENDER
# ─────────────────────────────────────────────

def send_email(to_email, subject, html_body):
    """
    Core function: Send an email using SMTP.
    Returns True if successful, False otherwise.
    """
    try:
        # Create email message
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = FROM_EMAIL
        msg['To'] = to_email

        # Attach HTML body
        part = MIMEText(html_body, 'html')
        msg.attach(part)

        # Connect to SMTP server and send
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.ehlo()
            server.starttls()                              # Enable TLS encryption
            server.login(SMTP_USER, SMTP_PASSWORD)         # Login to SMTP server
            server.sendmail(FROM_EMAIL, to_email, msg.as_string())

        logger.info(f"Email sent to {to_email}: {subject}")
        return True

    except smtplib.SMTPAuthenticationError:
        logger.error("SMTP authentication failed. Check your email and password.")
        return False
    except smtplib.SMTPException as e:
        logger.error(f"SMTP error: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Email send failed: {str(e)}")
        return False


# ─────────────────────────────────────────────
# EMAIL TEMPLATES
# ─────────────────────────────────────────────

def build_study_reminder_email(student_name, subjects_today):
    """HTML template for daily study reminder"""
    subjects_html = ""
    for s in subjects_today:
        subjects_html += f"<li style='padding:5px 0;'>📚 <strong>{s['subject']}</strong> — {s['duration']}</li>"

    return f"""
    <html>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 10px; text-align: center;">
            <h1 style="color: white; margin: 0;">📖 Smart Study Planner</h1>
            <p style="color: #e8e8e8;">Your Daily Study Reminder</p>
        </div>
        
        <div style="background: #f9f9f9; padding: 25px; border-radius: 10px; margin-top: 20px;">
            <h2 style="color: #333;">Hello, {student_name}! 👋</h2>
            <p style="color: #555;">Here's your study plan for today, <strong>{datetime.date.today().strftime('%A, %B %d')}</strong>:</p>
            
            <ul style="list-style: none; padding: 0; background: white; border-radius: 8px; padding: 15px;">
                {subjects_html}
            </ul>
            
            <div style="background: #e8f4fd; padding: 15px; border-radius: 8px; margin-top: 15px;">
                <h3 style="color: #2196F3; margin: 0 0 10px 0;">🍅 Pomodoro Tip</h3>
                <p style="margin: 0; color: #555;">Study for 25 minutes, then take a 5-minute break. 
                After 4 sessions, take a longer 15-minute break!</p>
            </div>
            
            <p style="color: #777; margin-top: 20px; font-size: 14px;">
                You got this! Consistency is key. 🚀
            </p>
        </div>
        
        <p style="text-align: center; color: #aaa; font-size: 12px; margin-top: 20px;">
            Smart Study Planner | AI-Powered Education
        </p>
    </body>
    </html>
    """


def build_missed_session_email(student_name, subject_name, missed_date):
    """HTML template for missed session alert"""
    return f"""
    <html>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px;">
        <div style="background: #ff6b6b; padding: 30px; border-radius: 10px; text-align: center;">
            <h1 style="color: white; margin: 0;">⚠️ Missed Study Session</h1>
        </div>
        
        <div style="background: #fff3f3; padding: 25px; border-radius: 10px; margin-top: 20px; border-left: 4px solid #ff6b6b;">
            <h2 style="color: #333;">Hi {student_name},</h2>
            <p style="color: #555;">We noticed you missed your <strong>{subject_name}</strong> study session on <strong>{missed_date}</strong>.</p>
            <p style="color: #555;">Don't worry! Your study plan has been adjusted. Here's what we recommend:</p>
            <ul style="color: #555;">
                <li>Add an extra 30 minutes to tomorrow's {subject_name} session</li>
                <li>Review the chapters you were meant to cover</li>
                <li>Log in to see your updated schedule</li>
            </ul>
            <p style="color: #777; font-size: 14px;">Remember: Missing one day is okay. Missing many days is what creates pressure. 💪</p>
        </div>
    </body>
    </html>
    """


def build_exam_countdown_email(student_name, subject_name, days_left, readiness_score):
    """HTML template for exam countdown alert"""
    color = "#4CAF50" if days_left > 7 else "#FF9800" if days_left > 3 else "#f44336"
    return f"""
    <html>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px;">
        <div style="background: {color}; padding: 30px; border-radius: 10px; text-align: center;">
            <h1 style="color: white; margin: 0;">⏳ Exam Countdown</h1>
            <p style="color: white; font-size: 24px; font-weight: bold;">{days_left} days left!</p>
        </div>
        
        <div style="background: #f9f9f9; padding: 25px; border-radius: 10px; margin-top: 20px;">
            <h2 style="color: #333;">Hello {student_name},</h2>
            <p style="color: #555;">Your <strong>{subject_name}</strong> exam is just <strong>{days_left} days away!</strong></p>
            <p style="color: #555;">Your current exam readiness score: <strong style="color: {color};">{readiness_score}%</strong></p>
            
            <div style="background: white; padding: 15px; border-radius: 8px; margin-top: 15px;">
                <h3 style="color: #333;">📋 Last-minute tips:</h3>
                <ul style="color: #555;">
                    <li>Focus on high-priority topics</li>
                    <li>Do past exam papers</li>
                    <li>Sleep well the night before</li>
                    <li>Review your notes one more time</li>
                </ul>
            </div>
            <p style="color: #777; font-size: 14px;">You've put in the work. Trust yourself. 🎯</p>
        </div>
    </body>
    </html>
    """


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy', 'service': 'notification-service'}), 200


@app.route('/send/reminder', methods=['POST'])
def send_reminder():
    """
    Send a daily study reminder email.
    Body: {
        "to_email": "student@example.com",
        "student_name": "Alice",
        "subjects_today": [{"subject": "Math", "duration": "2h"}]
    }
    """
    try:
        data = request.get_json()
        if not data or not data.get('to_email'):
            return jsonify({'error': 'Email address required'}), 400

        html_body = build_study_reminder_email(
            data.get('student_name', 'Student'),
            data.get('subjects_today', [])
        )

        success = send_email(
            data['to_email'],
            f"📚 Today's Study Plan — {datetime.date.today().strftime('%B %d')}",
            html_body
        )

        if success:
            return jsonify({'message': 'Reminder sent successfully'}), 200
        else:
            return jsonify({'error': 'Failed to send email. Check SMTP configuration.'}), 500

    except Exception as e:
        logger.error(f"Reminder error: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/send/missed', methods=['POST'])
def send_missed_alert():
    """
    Send a missed session alert.
    Body: { "to_email": "...", "student_name": "...", "subject_name": "...", "missed_date": "..." }
    """
    try:
        data = request.get_json()
        html_body = build_missed_session_email(
            data.get('student_name', 'Student'),
            data.get('subject_name', 'Subject'),
            data.get('missed_date', str(datetime.date.today()))
        )

        success = send_email(data['to_email'], '⚠️ Missed Study Session Alert', html_body)

        return jsonify({'message': 'Alert sent' if success else 'Failed to send'}), 200 if success else 500

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/send/exam-countdown', methods=['POST'])
def send_exam_countdown():
    """
    Send an exam countdown notification.
    Body: { "to_email": "...", "student_name": "...", "subject_name": "...", "days_left": 5, "readiness_score": 72 }
    """
    try:
        data = request.get_json()
        html_body = build_exam_countdown_email(
            data.get('student_name', 'Student'),
            data.get('subject_name', 'Exam'),
            data.get('days_left', 7),
            data.get('readiness_score', 50)
        )

        success = send_email(data['to_email'], f"⏳ {data.get('days_left', 7)} Days Until Your Exam!", html_body)

        return jsonify({'message': 'Countdown sent' if success else 'Failed'}), 200 if success else 500

    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    logger.info("Notification Service started")
    app.run(host='0.0.0.0', port=5006, debug=False)
