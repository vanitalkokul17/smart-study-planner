"""
Recommendation Service - Provides smart study tips and dynamic adjustments.
Analyzes progress and generates personalized recommendations.
"""

from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
import requests
import datetime
import os
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL', 'mysql+pymysql://root:password@mysql:3306/study_planner'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

USER_SERVICE_URL = os.environ.get('USER_SERVICE_URL', 'http://user-service:5001')
PROGRESS_SERVICE_URL = os.environ.get('PROGRESS_SERVICE_URL', 'http://progress-service:5004')


# ─────────────────────────────────────────────
# DATABASE MODEL
# ─────────────────────────────────────────────

class Recommendation(db.Model):
    """Stores generated recommendations for each user"""
    __tablename__ = 'recommendations'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    recommendation_text = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), default='general')  # general, urgent, motivational
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'text': self.recommendation_text,
            'category': self.category,
            'is_read': self.is_read,
            'created_at': str(self.created_at)
        }


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def verify_token(token):
    try:
        r = requests.post(f"{USER_SERVICE_URL}/verify", json={'token': token}, timeout=5)
        return r.json() if r.status_code == 200 else None
    except:
        return None


def get_token():
    auth = request.headers.get('Authorization', '')
    return auth.split(' ')[1] if auth.startswith('Bearer ') else None


def get_user_progress(user_id, token):
    """Fetch progress data from Progress Service"""
    try:
        r = requests.get(
            f"{PROGRESS_SERVICE_URL}/logs",
            headers={'Authorization': f'Bearer {token}'},
            timeout=5
        )
        return r.json() if r.status_code == 200 else None
    except:
        return None


# ─────────────────────────────────────────────
# RECOMMENDATION ENGINE
# ─────────────────────────────────────────────

def analyze_and_recommend(progress_data, user_id):
    """
    Smart rule-based recommendation engine.
    Generates personalized tips based on study behavior.
    """
    recommendations = []

    if not progress_data:
        return [
            {'text': '👋 Welcome! Start by logging your first study session.', 'category': 'general'},
            {'text': '📅 Set your exam dates to get a personalized plan.', 'category': 'general'}
        ]

    summary = progress_data.get('summary', {})
    logs = progress_data.get('logs', [])

    total_sessions = summary.get('total_sessions', 0)
    completed_sessions = summary.get('completed_sessions', 0)
    total_hours = summary.get('total_hours_studied', 0)

    # Check completion rate
    if total_sessions > 0:
        completion_rate = (completed_sessions / total_sessions) * 100

        if completion_rate < 30:
            recommendations.append({
                'text': '⚠️ Your session completion rate is below 30%. Try shorter, focused sessions using the Pomodoro technique.',
                'category': 'urgent'
            })
        elif completion_rate < 60:
            recommendations.append({
                'text': '📈 You\'re completing about half your sessions. Try studying at the same time each day to build a habit.',
                'category': 'general'
            })
        else:
            recommendations.append({
                'text': f'🌟 Excellent! You\'ve completed {completion_rate:.0f}% of your sessions. Keep this momentum!',
                'category': 'motivational'
            })

    # Check total hours
    if total_hours < 5:
        recommendations.append({
            'text': '⏰ You\'ve studied less than 5 hours total. Aim for at least 2 hours per day.',
            'category': 'urgent'
        })
    elif total_hours > 20:
        recommendations.append({
            'text': '💪 You\'ve put in over 20 hours! Make sure to take rest breaks — sleep is important for memory.',
            'category': 'general'
        })

    # Check study streak (consecutive days)
    if logs:
        today = datetime.date.today()
        recent_dates = sorted(set(l['session_date'] for l in logs[-7:]), reverse=True)
        streak = 0
        for i, date_str in enumerate(recent_dates):
            d = datetime.datetime.strptime(date_str, '%Y-%m-%d').date()
            if (today - d).days == i:
                streak += 1
            else:
                break

        if streak >= 7:
            recommendations.append({
                'text': f'🔥 Amazing! You have a {streak}-day study streak! You\'re building a great habit.',
                'category': 'motivational'
            })
        elif streak >= 3:
            recommendations.append({
                'text': f'✅ Good job! You\'ve studied {streak} days in a row. Keep it up to build a strong habit.',
                'category': 'motivational'
            })
        elif streak == 0:
            recommendations.append({
                'text': '📚 You haven\'t studied today. Even 25 minutes (1 Pomodoro) can make a big difference!',
                'category': 'urgent'
            })

    # General study tips
    study_tips = [
        {'text': '🧠 Use active recall: test yourself instead of just re-reading notes.', 'category': 'general'},
        {'text': '📝 Spaced repetition is the most effective way to memorize — review topics across multiple days.', 'category': 'general'},
        {'text': '🍎 Eat well and sleep 7-8 hours. Your brain consolidates learning during sleep.', 'category': 'general'},
    ]

    # Add one random tip
    import random
    recommendations.append(random.choice(study_tips))

    return recommendations


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy', 'service': 'recommendation-service'}), 200


@app.route('/recommendations', methods=['GET'])
def get_recommendations():
    """Get personalized recommendations based on user progress"""
    token = get_token()
    user_info = verify_token(token)
    if not user_info:
        return jsonify({'error': 'Unauthorized'}), 401

    user_id = user_info['user_id']

    # Get progress data
    progress_data = get_user_progress(user_id, token)

    # Generate recommendations
    new_recs = analyze_and_recommend(progress_data, user_id)

    # Save to database
    saved = []
    for rec in new_recs:
        db_rec = Recommendation(
            user_id=user_id,
            recommendation_text=rec['text'],
            category=rec['category']
        )
        db.session.add(db_rec)
        saved.append(db_rec)

    db.session.commit()

    return jsonify({
        'recommendations': [{'text': r['text'], 'category': r['category']} for r in new_recs],
        'count': len(new_recs)
    }), 200


@app.route('/recommendations/history', methods=['GET'])
def get_history():
    """Get past recommendations"""
    token = get_token()
    user_info = verify_token(token)
    if not user_info:
        return jsonify({'error': 'Unauthorized'}), 401

    recs = Recommendation.query.filter_by(
        user_id=user_info['user_id']
    ).order_by(Recommendation.created_at.desc()).limit(20).all()

    return jsonify({'history': [r.to_dict() for r in recs]}), 200


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        logger.info("Recommendation Service started")
    app.run(host='0.0.0.0', port=5005, debug=False)
