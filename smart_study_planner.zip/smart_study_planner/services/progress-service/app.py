"""
Progress Tracking Service - Tracks what students have completed
Students mark chapters/sessions as done, and this service logs it.
"""

from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
import requests
import datetime
import os
import logging

app = Flask(__name__)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL',
    'mysql+pymysql://root:password@mysql:3306/study_planner'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
USER_SERVICE_URL = os.environ.get('USER_SERVICE_URL', 'http://user-service:5001')


# ─────────────────────────────────────────────
# DATABASE MODELS
# ─────────────────────────────────────────────

class ProgressLog(db.Model):
    """Stores each study session completed by the student"""
    __tablename__ = 'progress_logs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    subject_id = db.Column(db.Integer, nullable=False)
    subject_name = db.Column(db.String(100), nullable=False)
    chapters_completed = db.Column(db.Integer, default=0)    # How many chapters done in this session
    hours_studied = db.Column(db.Float, default=0.0)         # Hours studied in this session
    session_date = db.Column(db.Date, default=datetime.date.today)
    notes = db.Column(db.Text, nullable=True)                # Optional notes from student
    is_completed = db.Column(db.Boolean, default=False)      # Was session fully completed?
    logged_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'subject_id': self.subject_id,
            'subject_name': self.subject_name,
            'chapters_completed': self.chapters_completed,
            'hours_studied': self.hours_studied,
            'session_date': str(self.session_date),
            'notes': self.notes,
            'is_completed': self.is_completed,
            'logged_at': str(self.logged_at)
        }


class MissedSession(db.Model):
    """Tracks missed study sessions for notifications and plan adjustment"""
    __tablename__ = 'missed_sessions'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    subject_name = db.Column(db.String(100), nullable=False)
    scheduled_date = db.Column(db.Date, nullable=False)
    reason = db.Column(db.String(255), nullable=True)
    flagged_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'subject_name': self.subject_name,
            'scheduled_date': str(self.scheduled_date),
            'reason': self.reason
        }


# ─────────────────────────────────────────────
# HELPER
# ─────────────────────────────────────────────

def verify_token(token):
    try:
        r = requests.post(f"{USER_SERVICE_URL}/verify", json={'token': token}, timeout=5)
        if r.status_code == 200:
            return r.json()
        return None
    except:
        return None


def get_token():
    auth = request.headers.get('Authorization', '')
    return auth.split(' ')[1] if auth.startswith('Bearer ') else None


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy', 'service': 'progress-service'}), 200


@app.route('/log', methods=['POST'])
def log_progress():
    """
    Log a completed study session.
    Body: {
        "subject_id": 1,
        "subject_name": "Mathematics",
        "chapters_completed": 2,
        "hours_studied": 1.5,
        "session_date": "2024-11-01",  (optional, defaults to today)
        "notes": "Completed algebra section",
        "is_completed": true
    }
    """
    token = get_token()
    user_info = verify_token(token)
    if not user_info:
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    # Parse date
    session_date = datetime.date.today()
    if data.get('session_date'):
        try:
            session_date = datetime.datetime.strptime(data['session_date'], '%Y-%m-%d').date()
        except:
            pass

    log = ProgressLog(
        user_id=user_info['user_id'],
        subject_id=data.get('subject_id', 0),
        subject_name=data.get('subject_name', 'Unknown'),
        chapters_completed=data.get('chapters_completed', 0),
        hours_studied=data.get('hours_studied', 0.0),
        session_date=session_date,
        notes=data.get('notes'),
        is_completed=data.get('is_completed', False)
    )

    db.session.add(log)
    db.session.commit()

    logger.info(f"Progress logged for user {user_info['user_id']}: {data.get('subject_name')}")
    return jsonify({'message': 'Progress logged successfully', 'log': log.to_dict()}), 201


@app.route('/logs', methods=['GET'])
def get_logs():
    """Get all progress logs for the authenticated user"""
    token = get_token()
    user_info = verify_token(token)
    if not user_info:
        return jsonify({'error': 'Unauthorized'}), 401

    user_id = user_info['user_id']
    logs = ProgressLog.query.filter_by(user_id=user_id).order_by(ProgressLog.session_date.desc()).all()

    # Calculate summary stats
    total_hours = sum(l.hours_studied for l in logs)
    total_chapters = sum(l.chapters_completed for l in logs)
    completed_sessions = sum(1 for l in logs if l.is_completed)

    return jsonify({
        'logs': [l.to_dict() for l in logs],
        'summary': {
            'total_sessions': len(logs),
            'completed_sessions': completed_sessions,
            'total_hours_studied': round(total_hours, 2),
            'total_chapters_completed': total_chapters
        }
    }), 200


@app.route('/miss', methods=['POST'])
def report_missed():
    """
    Report a missed study session.
    Body: { "subject_name": "Physics", "scheduled_date": "2024-11-01", "reason": "Was sick" }
    """
    token = get_token()
    user_info = verify_token(token)
    if not user_info:
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    scheduled_date = datetime.date.today()
    if data.get('scheduled_date'):
        try:
            scheduled_date = datetime.datetime.strptime(data['scheduled_date'], '%Y-%m-%d').date()
        except:
            pass

    missed = MissedSession(
        user_id=user_info['user_id'],
        subject_name=data.get('subject_name', 'Unknown'),
        scheduled_date=scheduled_date,
        reason=data.get('reason')
    )

    db.session.add(missed)
    db.session.commit()

    return jsonify({'message': 'Missed session recorded. Your plan will adjust accordingly.', 'missed': missed.to_dict()}), 201


@app.route('/missed', methods=['GET'])
def get_missed():
    """Get all missed sessions for the user"""
    token = get_token()
    user_info = verify_token(token)
    if not user_info:
        return jsonify({'error': 'Unauthorized'}), 401

    missed = MissedSession.query.filter_by(user_id=user_info['user_id']).all()
    return jsonify({'missed_sessions': [m.to_dict() for m in missed], 'count': len(missed)}), 200


@app.route('/progress-percent/<int:user_id>', methods=['GET'])
def get_progress_percent(user_id):
    """
    Calculate overall progress percentage.
    Used by AI Planner for readiness prediction.
    """
    logs = ProgressLog.query.filter_by(user_id=user_id).all()
    if not logs:
        return jsonify({'progress_percent': 0}), 200

    completed = sum(1 for l in logs if l.is_completed)
    percent = round((completed / len(logs)) * 100, 2)
    return jsonify({'progress_percent': percent, 'total_sessions': len(logs), 'completed': completed}), 200


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        logger.info("Progress Tracking Service started")
    app.run(host='0.0.0.0', port=5004, debug=False)
