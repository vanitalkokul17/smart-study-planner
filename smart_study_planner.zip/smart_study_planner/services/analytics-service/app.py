"""
Analytics Service - Performance Reports & Dashboard Data
Aggregates data from progress logs and generates analytics.
"""

from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
import requests
import datetime
import os
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL', 'mysql+pymysql://root:password@mysql:3306/study_planner'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

USER_SERVICE_URL = os.environ.get('USER_SERVICE_URL', 'http://user-service:5001')
PROGRESS_SERVICE_URL = os.environ.get('PROGRESS_SERVICE_URL', 'http://progress-service:5004')
AI_PLANNER_URL = os.environ.get('AI_PLANNER_URL', 'http://ai-planner-service:5003')


def verify_token(token):
    try:
        r = requests.post(f"{USER_SERVICE_URL}/verify", json={'token': token}, timeout=5)
        return r.json() if r.status_code == 200 else None
    except:
        return None


def get_token():
    auth = request.headers.get('Authorization', '')
    return auth.split(' ')[1] if auth.startswith('Bearer ') else None


def fetch_progress(token):
    try:
        r = requests.get(
            f"{PROGRESS_SERVICE_URL}/logs",
            headers={'Authorization': f'Bearer {token}'}, timeout=5
        )
        return r.json() if r.status_code == 200 else {'logs': [], 'summary': {}}
    except:
        return {'logs': [], 'summary': {}}


def calculate_subject_breakdown(logs):
    breakdown = {}
    for log in logs:
        name = log['subject_name']
        if name not in breakdown:
            breakdown[name] = {'hours': 0, 'chapters': 0, 'sessions': 0}
        breakdown[name]['hours'] += log['hours_studied']
        breakdown[name]['chapters'] += log['chapters_completed']
        breakdown[name]['sessions'] += 1
    for subject in breakdown:
        breakdown[subject]['hours'] = round(breakdown[subject]['hours'], 2)
    return breakdown


def calculate_weekly_trend(logs):
    today = datetime.date.today()
    trend = {}
    for i in range(6, -1, -1):
        day = today - datetime.timedelta(days=i)
        trend[str(day)] = 0
    for log in logs:
        date_str = log['session_date']
        if date_str in trend:
            trend[date_str] = round(trend[date_str] + log['hours_studied'], 2)
    return trend


def calculate_performance_score(summary):
    total = summary.get('total_sessions', 0)
    completed = summary.get('completed_sessions', 0)
    hours = summary.get('total_hours_studied', 0)
    if total == 0:
        return 0
    completion_rate = (completed / total) * 50
    hours_score = min(hours * 2, 30)
    sessions_score = min(total * 2, 20)
    return round(completion_rate + hours_score + sessions_score, 1)


def get_performance_grade(score):
    if score >= 85:
        return 'A', 'Excellent'
    elif score >= 70:
        return 'B', 'Good'
    elif score >= 55:
        return 'C', 'Average'
    elif score >= 40:
        return 'D', 'Below Average'
    else:
        return 'F', 'Poor - Study more consistently'


def calculate_best_study_day(logs):
    day_hours = {'Monday': 0, 'Tuesday': 0, 'Wednesday': 0,
                 'Thursday': 0, 'Friday': 0, 'Saturday': 0, 'Sunday': 0}
    for log in logs:
        try:
            d = datetime.datetime.strptime(log['session_date'], '%Y-%m-%d').date()
            day_name = d.strftime('%A')
            day_hours[day_name] += log['hours_studied']
        except:
            pass
    if all(v == 0 for v in day_hours.values()):
        return 'No data yet'
    return max(day_hours, key=day_hours.get)


@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy', 'service': 'analytics-service'}), 200


@app.route('/dashboard', methods=['GET'])
def get_dashboard():
    token = get_token()
    user_info = verify_token(token)
    if not user_info:
        return jsonify({'error': 'Unauthorized'}), 401

    user_id = user_info['user_id']
    progress_data = fetch_progress(token)
    logs = progress_data.get('logs', [])
    summary = progress_data.get('summary', {})

    subject_breakdown = calculate_subject_breakdown(logs)
    weekly_trend = calculate_weekly_trend(logs)
    performance_score = calculate_performance_score(summary)
    grade, grade_label = get_performance_grade(performance_score)
    best_day = calculate_best_study_day(logs)

    readiness_score = 0
    try:
        ai_r = requests.post(
            f"{AI_PLANNER_URL}/readiness",
            json={'subjects': [], 'progress_percent': summary.get('completed_sessions', 0)},
            timeout=5
        )
        if ai_r.status_code == 200:
            readiness_score = ai_r.json().get('readiness_score', 0)
    except:
        pass

    dashboard = {
        'user_id': user_id,
        'generated_at': str(datetime.datetime.now()),
        'summary': {
            'total_sessions': summary.get('total_sessions', 0),
            'completed_sessions': summary.get('completed_sessions', 0),
            'total_hours_studied': summary.get('total_hours_studied', 0),
            'total_chapters_completed': summary.get('total_chapters_completed', 0),
            'completion_rate_percent': round(
                (summary.get('completed_sessions', 0) / max(summary.get('total_sessions', 1), 1)) * 100, 1
            ),
            'missed_sessions': summary.get('total_sessions', 0) - summary.get('completed_sessions', 0),
            'exam_readiness': readiness_score
        },
        'performance': {
            'score': performance_score,
            'grade': grade,
            'label': grade_label,
            'exam_readiness': readiness_score,
            'missed_sessions': (summary.get('total_sessions', 0) - summary.get('completed_sessions', 0)),
            'best_study_day': best_day
        },
        'charts': {
            'weekly_hours_trend': weekly_trend,
            'subject_breakdown': subject_breakdown,
        },
        'message': f"Performance grade: {grade} — {grade_label}"
    }

    logger.info(f"Dashboard generated for user {user_id}")
    return jsonify(dashboard), 200


@app.route('/report', methods=['GET'])
def get_report():
    token = get_token()
    user_info = verify_token(token)
    if not user_info:
        return jsonify({'error': 'Unauthorized'}), 401

    period = int(request.args.get('period', 7))
    progress_data = fetch_progress(token)
    logs = progress_data.get('logs', [])
    summary = progress_data.get('summary', {})

    cutoff = datetime.date.today() - datetime.timedelta(days=period)
    recent_logs = [
        l for l in logs
        if datetime.datetime.strptime(l['session_date'], '%Y-%m-%d').date() >= cutoff
    ]

    period_hours = sum(l['hours_studied'] for l in recent_logs)
    period_chapters = sum(l['chapters_completed'] for l in recent_logs)
    period_sessions = len(recent_logs)
    period_completed = sum(1 for l in recent_logs if l['is_completed'])

    report = {
        'period_days': period,
        'from_date': str(cutoff),
        'to_date': str(datetime.date.today()),
        'stats': {
            'sessions': period_sessions,
            'completed_sessions': period_completed,
            'hours_studied': round(period_hours, 2),
            'chapters_completed': period_chapters,
            'avg_hours_per_day': round(period_hours / period, 2),
            'completion_rate': round((period_completed / max(period_sessions, 1)) * 100, 1)
        },
        'subject_breakdown': calculate_subject_breakdown(recent_logs),
        'overall_performance_score': calculate_performance_score(summary),
    }

    return jsonify(report), 200


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        logger.info("Analytics Service started")
    app.run(host='0.0.0.0', port=5007, debug=False)
