"""
User Service - Handles Registration, Login, and JWT Authentication
This is the entry point for all user-related operations.
"""

from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
import jwt
import datetime
import os
import logging

# Initialize Flask app
app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration from environment variables
app.config['SECRET_KEY'] = os.environ.get('JWT_SECRET', 'your-secret-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL',
    'mysql+pymysql://root:password@mysql:3306/study_planner'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)


# ─────────────────────────────────────────────
# DATABASE MODEL
# ─────────────────────────────────────────────
class User(db.Model):
    """User model - stores all registered users"""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    def to_dict(self):
        """Convert user object to dictionary (exclude password)"""
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'created_at': str(self.created_at)
        }


# ─────────────────────────────────────────────
# HELPER FUNCTIONS
# ─────────────────────────────────────────────
def generate_token(user_id, email):
    """Generate a JWT token for authenticated users"""
    payload = {
        'user_id': user_id,
        'email': email,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(days=30)  # Token expires in 30 days
    }
    token = jwt.encode(payload, app.config['SECRET_KEY'], algorithm='HS256')
    return token


def verify_token(token):
    """Verify and decode a JWT token"""
    try:
        payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
        return payload
    except jwt.ExpiredSignatureError:
        return None  # Token has expired
    except jwt.InvalidTokenError:
        return None  # Invalid token


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint - used by Docker and load balancers"""
    return jsonify({'status': 'healthy', 'service': 'user-service'}), 200


@app.route('/register', methods=['POST'])
def register():
    """
    Register a new user
    Body: { "name": "...", "email": "...", "password": "..." }
    """
    try:
        data = request.get_json()

        # Validate required fields
        if not data or not data.get('name') or not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Name, email, and password are required'}), 400

        # Check if email already exists
        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user:
            return jsonify({'error': 'Email already registered'}), 409

        # Hash the password before storing
        hashed_password = bcrypt.generate_password_hash(data['password']).decode('utf-8')

        # Create new user
        new_user = User(
            name=data['name'],
            email=data['email'],
            password=hashed_password
        )

        db.session.add(new_user)
        db.session.commit()

        logger.info(f"New user registered: {data['email']}")

        return jsonify({
            'message': 'User registered successfully',
            'user': new_user.to_dict()
        }), 201

    except Exception as e:
        logger.error(f"Registration error: {str(e)}")
        db.session.rollback()
        return jsonify({'error': 'Registration failed'}), 500


@app.route('/login', methods=['POST'])
def login():
    """
    Login a user and return JWT token
    Body: { "email": "...", "password": "..." }
    """
    try:
        data = request.get_json()

        if not data or not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Email and password are required'}), 400

        # Find user by email
        user = User.query.filter_by(email=data['email']).first()

        # Check if user exists and password matches
        if not user or not bcrypt.check_password_hash(user.password, data['password']):
            return jsonify({'error': 'Invalid email or password'}), 401

        # Generate JWT token
        token = generate_token(user.id, user.email)

        logger.info(f"User logged in: {data['email']}")

        return jsonify({
            'message': 'Login successful',
            'token': token,
            'user': user.to_dict()
        }), 200

    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        return jsonify({'error': 'Login failed'}), 500


@app.route('/verify', methods=['POST'])
def verify():
    """
    Verify a JWT token (used by other services to validate users)
    Body: { "token": "..." }
    """
    try:
        data = request.get_json()
        token = data.get('token')

        if not token:
            return jsonify({'valid': False, 'error': 'Token is required'}), 400

        payload = verify_token(token)

        if payload:
            return jsonify({'valid': True, 'user_id': payload['user_id'], 'email': payload['email']}), 200
        else:
            return jsonify({'valid': False, 'error': 'Invalid or expired token'}), 401

    except Exception as e:
        logger.error(f"Token verification error: {str(e)}")
        return jsonify({'valid': False, 'error': 'Verification failed'}), 500


@app.route('/profile/<int:user_id>', methods=['GET'])
def get_profile(user_id):
    """Get a user's profile by ID"""
    user = User.query.get(user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404
    return jsonify({'user': user.to_dict()}), 200


# ─────────────────────────────────────────────
# APP STARTUP
# ─────────────────────────────────────────────
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create tables if they don't exist
        logger.info("User Service started successfully")
    app.run(host='0.0.0.0', port=5001, debug=False)
