# 📖 AI-Powered Smart Study Planner

> A containerized microservices application that helps students create personalized study plans, track progress, and predict exam readiness using AI.

![Architecture](https://img.shields.io/badge/Architecture-Microservices-blue)
![Docker](https://img.shields.io/badge/Docker-Compose-2496ED?logo=docker)
![Python](https://img.shields.io/badge/Python-3.11-3776AB?logo=python)
![MySQL](https://img.shields.io/badge/Database-MySQL%208.0-4479A1?logo=mysql)
![Nginx](https://img.shields.io/badge/Gateway-Nginx-009639?logo=nginx)

---

## ✨ Features

- 🔐 **JWT Authentication** — Secure register & login
- 📚 **Subject Management** — Add subjects with exam dates, priorities, chapters
- 🤖 **AI Study Plan Generator** — Personalized timetable using urgency scoring + ML
- 📅 **Weekly Timetable** — Auto-generated Mon–Fri schedule
- 🍅 **Pomodoro Timer** — Built-in 25/5 min focus timer
- 📊 **Dashboard Analytics** — Charts for weekly hours, subject breakdown, performance grade
- 📈 **Exam Readiness Prediction** — scikit-learn Linear Regression model (0–100%)
- 💡 **Smart Recommendations** — Rule-based personalized study tips
- 📧 **Email Notifications** — Reminders, missed session alerts, exam countdowns (SMTP)
- 🔄 **Dynamic Adjustment** — Plan adapts based on missed sessions and progress

---

## 🏗️ Architecture

```
Client Browser
     │
     ▼
┌──────────────────────────┐
│   Nginx API Gateway :80  │  ← Single entry point
└──────────────────────────┘
     │ routes to...
     ├─► User Service        :5001  (Flask + JWT)
     ├─► Study Plan Service  :5002  (Flask + MySQL)
     ├─► AI Planner Service  :5003  (Flask + scikit-learn)
     ├─► Progress Service    :5004  (Flask + MySQL)
     ├─► Recommendation Svc  :5005  (Flask + MySQL)
     ├─► Notification Svc    :5006  (Flask + SMTP)
     └─► Analytics Service   :5007  (Flask + MySQL)
                                        │
                               ┌────────▼────────┐
                               │  MySQL :3306     │
                               └─────────────────┘
```

---

## 🛠️ Tech Stack

| Layer        | Technology                        |
|-------------|-----------------------------------|
| Backend     | Python 3.11, Flask                |
| AI/ML       | scikit-learn, NumPy               |
| Database    | MySQL 8.0, SQLAlchemy             |
| Gateway     | Nginx                             |
| Auth        | JWT (PyJWT), bcrypt               |
| Email       | smtplib (SMTP)                    |
| Frontend    | HTML5, CSS3, Vanilla JS           |
| Container   | Docker, Docker Compose            |

---

## 📁 Project Structure

```
smart-study-planner/
├── docker-compose.yml
├── .env.example
├── .gitignore
├── README.md
├── nginx/
│   ├── Dockerfile
│   └── nginx.conf
├── frontend/
│   └── index.html
├── mysql-init/
│   └── init.sql
└── services/
    ├── user-service/
    │   ├── app.py
    │   ├── requirements.txt
    │   └── Dockerfile
    ├── study-plan-service/
    │   ├── app.py
    │   ├── requirements.txt
    │   └── Dockerfile
    ├── ai-planner-service/
    │   ├── app.py
    │   ├── requirements.txt
    │   └── Dockerfile
    ├── progress-service/
    │   ├── app.py
    │   ├── requirements.txt
    │   └── Dockerfile
    ├── recommendation-service/
    │   ├── app.py
    │   ├── requirements.txt
    │   └── Dockerfile
    ├── notification-service/
    │   ├── app.py
    │   ├── requirements.txt
    │   └── Dockerfile
    └── analytics-service/
        ├── app.py
        ├── requirements.txt
        └── Dockerfile
```

---

## 🚀 Setup & Run Instructions

### Prerequisites
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed
- [Git](https://git-scm.com/) installed

### Step 1 — Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/smart-study-planner.git
cd smart-study-planner
```

### Step 2 — Configure Environment Variables
```bash
cp .env.example .env
# Open .env and fill in your values (DB password, JWT secret, SMTP credentials)
```

### Step 3 — Build & Start All Services
```bash
docker-compose up --build
```
> First run takes ~3–5 minutes to build all images.

### Step 4 — Access the App
| Service       | URL                        |
|--------------|----------------------------|
| Frontend     | http://localhost           |
| User API     | http://localhost/api/users/ |
| Study Plan   | http://localhost/api/study/ |
| Analytics    | http://localhost/api/analytics/ |

### Stop the App
```bash
docker-compose down          # Stop containers
docker-compose down -v       # Stop + delete database
```

---

## 📡 API Endpoints

### User Service
| Method | Endpoint               | Description        |
|--------|------------------------|--------------------|
| POST   | /api/users/register    | Register new user  |
| POST   | /api/users/login       | Login & get token  |
| POST   | /api/users/verify      | Verify JWT token   |
| GET    | /api/users/profile/:id | Get user profile   |

### Study Plan Service
| Method | Endpoint                  | Description           |
|--------|---------------------------|-----------------------|
| POST   | /api/study/subjects       | Add a subject         |
| GET    | /api/study/subjects       | List all subjects     |
| DELETE | /api/study/subjects/:id   | Delete a subject      |
| POST   | /api/study/generate-plan  | Generate AI plan      |
| GET    | /api/study/plan           | Get current plan      |

### Progress Service
| Method | Endpoint                   | Description            |
|--------|----------------------------|------------------------|
| POST   | /api/progress/log          | Log study session      |
| GET    | /api/progress/logs         | Get all logs           |
| POST   | /api/progress/miss         | Report missed session  |

### Analytics Service
| Method | Endpoint                     | Description          |
|--------|------------------------------|----------------------|
| GET    | /api/analytics/dashboard     | Full dashboard data  |
| GET    | /api/analytics/report?period=7 | Period report      |

---

## 🧪 Test Login
```
Email:    test@example.com
Password: password123
```

---

## ☁️ AWS Deployment Guide

### Option 1: EC2 + Docker
1. Launch an EC2 t2.medium (Ubuntu 22.04)
2. Install Docker: `sudo apt install docker.io docker-compose -y`
3. Clone your repo and run `docker-compose up -d`
4. Open ports 80, 443 in Security Groups

### Option 2: AWS ECS (Elastic Container Service)
1. Push each Dockerfile to Amazon ECR
2. Create an ECS cluster with Fargate
3. Define task definitions for each service
4. Use RDS MySQL instead of the MySQL container
5. Put an Application Load Balancer in front

---

## 🤝 Contributing

1. Fork the repo
2. Create a branch: `git checkout -b feature/my-feature`
3. Commit: `git commit -m "Add my feature"`
4. Push: `git push origin feature/my-feature`
5. Open a Pull Request

---

## 📄 License

MIT License — free to use and modify.

---

*Built with ❤️ using Python, Flask, Docker, and scikit-learn*
