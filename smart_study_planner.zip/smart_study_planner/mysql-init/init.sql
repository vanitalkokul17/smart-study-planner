-- Smart Study Planner - MySQL Database Schema
CREATE DATABASE IF NOT EXISTS study_planner;
USE study_planner;

CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email)
);

CREATE TABLE IF NOT EXISTS subjects (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    name            VARCHAR(100) NOT NULL,
    total_chapters  INT DEFAULT 0,
    priority        ENUM('high', 'medium', 'low') DEFAULT 'medium',
    exam_date       DATE,
    daily_hours     FLOAT DEFAULT 1.0,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id)
);

CREATE TABLE IF NOT EXISTS study_plans (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    plan_data       LONGTEXT NOT NULL,
    is_active       BOOLEAN DEFAULT TRUE,
    generated_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_active (user_id, is_active)
);

CREATE TABLE IF NOT EXISTS progress_logs (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    user_id             INT NOT NULL,
    subject_id          INT NOT NULL,
    subject_name        VARCHAR(100) NOT NULL,
    chapters_completed  INT DEFAULT 0,
    hours_studied       FLOAT DEFAULT 0.0,
    session_date        DATE NOT NULL,
    notes               TEXT,
    is_completed        BOOLEAN DEFAULT FALSE,
    logged_at           DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_date (user_id, session_date)
);

CREATE TABLE IF NOT EXISTS missed_sessions (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    subject_name    VARCHAR(100) NOT NULL,
    scheduled_date  DATE NOT NULL,
    reason          VARCHAR(255),
    flagged_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id)
);

CREATE TABLE IF NOT EXISTS recommendations (
    id                      INT AUTO_INCREMENT PRIMARY KEY,
    user_id                 INT NOT NULL,
    recommendation_text     TEXT NOT NULL,
    category                ENUM('general', 'urgent', 'motivational') DEFAULT 'general',
    is_read                 BOOLEAN DEFAULT FALSE,
    created_at              DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id)
);

INSERT IGNORE INTO users (id, name, email, password) VALUES
(1, 'Test Student', 'test@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LeuESFuD7BxFq4zLO');

INSERT IGNORE INTO subjects (user_id, name, total_chapters, priority, exam_date, daily_hours) VALUES
(1, 'Mathematics',  12, 'high',   DATE_ADD(CURDATE(), INTERVAL 14 DAY), 2.0),
(1, 'Physics',      10, 'high',   DATE_ADD(CURDATE(), INTERVAL 21 DAY), 1.5),
(1, 'Chemistry',     8, 'medium', DATE_ADD(CURDATE(), INTERVAL 28 DAY), 1.0),
(1, 'English',       6, 'low',    DATE_ADD(CURDATE(), INTERVAL 35 DAY), 1.0);

SELECT 'Database initialized successfully!' AS status;
